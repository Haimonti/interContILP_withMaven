#!/bin/sh

RANDOM=$$
MAX=`wc -l all_determs.pl | awk '{print $1}'`
R=$(($(($RANDOM%MAX))+1))
echo $R
./rsplit $R all_determs.pl determs.pl determs_left.pl
