has_car(T,C) :- member(C,T).

infront(T,C1,C2) :- append(_,[C2,C1|_],T).

shape(C,Shape):-
	arg(2,C,Shape),
	shape(Shape).

ellipse(C) :- arg(2,C,ellipse).
hexagon(C) :- arg(2,C,hexagon).
rectangle(C) :- arg(2,C,rectangle).
u_shaped(C) :- arg(2,C,u_shaped).
bucket(C) :- arg(2,C,bucket).

long(C) :- arg(3,C,long).
short(C) :- arg(3,C,short).

double(C) :- arg(4,C,double).

has_roof(C,R) :- arg(5,C,R).

open_car(C) :- arg(5,C,none).

closed(C) :- not(open_car(C)).

has_wheel(C,w(NC,W)) :- arg(1,C,NC), arg(6,C,NW), nlist(1,NW,L), member(W,L).

has_load(C,Load) :- arg(7,C,l(_,NLoad)), nlist(1,NLoad,L), member(Load,L).

has_load0(C,nil) :- arg(7,C,nil).

has_load0(C,Shape) :- arg(7,C,l(Shape,N)), 1=<N.

has_load1(T,Shape) :- has_car(T,C), has_load0(C,Shape).

load(C,Shape,N) :- arg(7,C,l(Shape,N)).

wheels(C,N) :- arg(6,C,N).

none(C) :- has_roof(C,none).
flat(C) :- has_roof(C,flat).
jagged(C) :- has_roof(C,jagged).
peaked(C) :- has_roof(C,peaked).
arc(C) :- has_roof(C,arc).

member(X,[X|_]).
member(X,[_|T]) :- member(X,T).

nlist(N,N,[N]) :- !.
nlist(M,N,[M|T]) :-
	M=<N,
	M1 is M+1, nlist(M1,N,T), !.

has_wheel(Train,Wheel) :-
	has_car(Train,Car),
	has_wheel(Car,Wheel).
has_load(Train,Load) :-
	has_car(Train,Car),
	has_load(Car,Load).
has_roof(Train,Roof) :-
	has_car(Train,Car),
	has_roof(Car,Roof).

subset([],_).
subset([H|T1],[H|T2]) :-
	subset(T1,T2).
subset(S,[_|T]) :-
	subset(S,T).

append([],L,L).
append([H|L1],L2,[H|L3]) :-
	append(L1,L2,L3).

%%%%%%%%%%%%%%%%%%%%%%%
% Meta-Types

rel(has_car).  rel(has_load1).  rel(has_wheel). rel(has_load).  rel(has_roof).

prop(short).  prop(closed).  prop(double).
prop(none).  prop(flat).  prop(jagged).  prop(peaked).  prop(arc).

plist([]).
plist([Prop|L]) :- prop(Prop), plist(L).

shape(circle).  shape(ellipse).  shape(hexagon).  shape(rectangle).
shape(triangle).  shape(utriangle).  shape(u_shaped). shape(diamond).



