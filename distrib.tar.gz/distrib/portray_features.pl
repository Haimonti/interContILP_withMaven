% code to display examples as feature-vectors

:- set(format,arff).
:- set(relation,relfeatures).
:- set(classes,[1,0]).

:- set(portray_examples,true).

:- set(train_pos,'train.f').
:- set(train_neg,'train.n').
:- set(test_pos,'test.f').
:- set(test_neg,'test.n').


aleph_portray(train_pos):-
	setting(train_pos,File),
	(setting(dependent,_) -> true; class(train_pos,Class)),
	setting(format,Format),
	show_feature_vectors(Format,File,Class).
aleph_portray(train_neg):-
	setting(train_neg,File),
	(setting(dependent,_) -> true; class(train_neg,Class)),
	setting(format,Format),
	show_feature_vectors(Format,File,Class).
aleph_portray(test_pos):-
	setting(test_pos,File),
	(setting(dependent,_) -> true; class(test_pos,Class)),
	setting(format,Format),
	show_feature_vectors(Format,File,Class).
aleph_portray(test_neg):-
	setting(test_neg,File),
	(setting(dependent,_) -> true; class(test_neg,Class)),
	setting(format,Format),
	show_feature_vectors(Format,File,Class).
aleph_portray(sample_data):-
	setting(sample_data,File),
	(setting(dependent,_) -> true; class(test_pos,Class)),
	setting(format,Format),
	show_feature_vectors(Format,File,Class).

class(train_pos,1).
class(train_neg,0).
class(test_pos,1).
class(test_neg,0).

show_feature_vectors(Format,File,Class):-
	findall(N,feature(N,_),FeatureNums),
	sort(FeatureNums,FeatureList),
	show_header(Format,FeatureList),
	open(File,read,Stream),
	repeat,
	read(Stream,Example),
	(Example = end_of_file -> close(Stream);
		show_feature_vector(Format,Example,FeatureList),
		(var(Class) -> true; write(' '), write(Class), nl),
		fail),			
	!.

show_header(arff,FeatureList):-
	setting(relation,Relation),
	write('@relation '), write(Relation), nl,
	mem(Feature,FeatureList),
	write('@attribute'), write(' '),
	write('ilp'), write(Feature), tab(8),
	write('{0,1}'), nl,
	fail.
show_header(arff,_):-
	setting(classes,Classes),
	write('@attribute class '), tab(8),
	write('{'),
	write_classes(Classes), write('}'),
	nl, nl,
	write('@data'), nl, nl.

write_classes([Class]):-
	write(Class), !.
write_classes([Class|Classes]):-
	write(Class), write(','),
	write_classes(Classes).

show_feature_vector(arff,Example,FeatureList):-
	mem(Feature,FeatureList),
	feature(Feature,(Example:- Body)),
	(once(Body) -> write(1), write(', '); write(0), write(', ')),
	fail.
show_feature_vector(arff,Example,_):-
	setting(dependent,PredArg),	!,
	arg(PredArg,Example,PredVal),
	writeq(PredVal), nl.
show_feature_vector(_,_,_).

writeq_list([]).
writeq_list([X|T]):-
        writeq(X), write('.'), nl,
        writeq_list(T).

mem(X,[X|_]).
mem(X,[_|T]):- mem(X,T).

