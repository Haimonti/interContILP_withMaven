#!/bin/sh

DESCR="Generate union of feature files"
USAGE="Usage: $0 Infile1 Infile2 [Infile3 ...] Outfile"

if [ "$#" -lt 3 ]; then
	echo "$DESCR"
	echo "$USAGE"
	exit 1
fi

/bin/rm /tmp/features*.pl
cp $1 /tmp/features.pl
shift

while [ "$#" -gt 1 ] 
do
yap <<+
consult('union_features.pl').
tell('/tmp/features_union.pl'), union('/tmp/features.pl','$1'), told.
+
mv /tmp/features_union.pl /tmp/features.pl
shift
done

cat /tmp/features.pl | grep -v "features from " > $1
/bin/rm /tmp/features*.pl
