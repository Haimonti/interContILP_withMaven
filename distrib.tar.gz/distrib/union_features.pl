:- [aleph].

union(File1,File2):-
	consult(File1),
	retract('$aleph_feature_count'(N)),
	add_features(File2,N),
	show(features).

add_features(File,N):-
	open(File,read,Stream),
	repeat,
	read(Stream,Fact),
	(Fact = end_of_file -> close(Stream);
		process(Fact,N),
		fail).

process(Fact,N):-
	Fact =.. [Name,Index|Args],
	Index1 is N + Index,
	Fact1 =.. [Name,Index1|Args],
	assertz(Fact1).
	

