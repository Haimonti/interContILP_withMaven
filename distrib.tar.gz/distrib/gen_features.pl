:- source.

:- [subtle].

:- dynamic cache/2.


rand_gen_features(CType,N):-
	retractall(cache(_,_)),
	store_values([construct_bottom,clausetype]),
	set(clausetype,CType),
	% set(construct_bottom,false),
	set(counter,1), set(maxcounter,N),
	rand_gen_features.


rand_gen_features:-
	setting(maxcounter,Max),
	repeat,
	rsat,
	sample_clauses(1,[L-[_,_,_,Clause]]),
	clause_to_list(Clause,CL),
	(seen(L,CL) -> true;
		asserta(cache(L,CL)),
		gen_feature(Clause,[])),
	setting(counter,N),
	N1 is N + 1,
	set(counter,N1),
	N1 > Max, !.
	

seen(L,CL):-
	cache(L,CL1),
	equiv(CL1,CL), !.

	
