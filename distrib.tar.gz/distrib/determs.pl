:- determination(pos/1,double/1).
:- determination(pos/1,wheels/2).
