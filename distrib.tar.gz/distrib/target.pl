
target(T):-
	has_car(T,C),
	short(C),
	closed(C).
