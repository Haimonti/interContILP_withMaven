#!/bin/sh

DESCR="Generate union of background files"
USAGE="Usage: $0 Infile1 [Infile2 Infile3 ...] Outfile"
if [ "$#" -lt 2 ]; then
	echo "$DESCR"
	echo "$USAGE"
	exit 1
fi
/bin/rm /tmp/back.pl

# while (( "$#" ))
while [ "$#" -gt 1 ] 
do
	echo ":- reconsult($1)." >> /tmp/back,pl
	shift
done
mv /tmp/back.pl $1

/bin/rm background.pl
ln -s $1 background.pl
