#!/bin/sh

# Generate determinations: change 0 to 1 to randomly select background
./gen_determs.sh 0 all_determs.pl determs1.pl

# Generate background file
./gen_back.sh modes1.pl determs1.pl back1.pl background1.pl

# Get a sample from the population
./gen_data.sh 1000 population.pl data.pl

# Generate pos and neg classes in data using target and background
./gen_classes.sh target.pl data.pl background1.pl classes.pl 

# Generate first-order features 
./gen_features.sh 500 features.pl

# Generate arff file
./portray_features.sh classes.pl features.pl




