:- determination(pos/1,short/1).
:- determination(pos/1,closed/1).
:- determination(pos/1,long/1).
:- determination(pos/1,open_car/1).
:- determination(pos/1,jagged/1).
:- determination(pos/1,shape/2).
:- determination(pos/1,load/3).
