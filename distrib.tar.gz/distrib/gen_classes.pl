gen_classes:-
	train(T),
	(once(target(T)) -> write(pos(T)); write(neg(T))),
	write('.'), nl,
	fail.
gen_classes.
	
